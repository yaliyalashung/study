#include "Animal.h"

Animal::Animal(int legs, const char* name){
    this->legs = legs;
    strcpy(this->name, name);
}

void Animal::printInfo(){
    printf("동물의 이름 : %s, 다리 개수 : %d\n", name, legs);
}