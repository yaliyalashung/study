#include <cstdio>
#include <cstring>
#include <cmath>
#include <cstdlib>
#include <ctime>